let speaking = false;

function convertToSpeech() {
  if (speaking) {
    window.speechSynthesis.cancel(); // Cancel the ongoing speech synthesis
    speaking = false;
    return;
  }

  const text = document.getElementById('text-to-convert').value;

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-US';
  utterance.rate = 1;
  utterance.pitch = 1;

  utterance.onstart = function() {
    speaking = true;
  };

  utterance.onend = function() {
    speaking = false;
  };

  window.speechSynthesis.speak(utterance);
}
